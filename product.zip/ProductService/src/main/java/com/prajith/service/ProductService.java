package com.prajith.service;

import java.util.List;

import com.prajith.model.ProductDTO;
import com.prajith.vo.ProductWithDescriptionVO;

public interface ProductService {
	public ProductDTO addProduct(ProductDTO product);

	public ProductDTO getProductById(Integer id);

	public List<ProductDTO> getProductByType(String type);

	public ProductWithDescriptionVO getProductANdDescpById(Integer id);

}
