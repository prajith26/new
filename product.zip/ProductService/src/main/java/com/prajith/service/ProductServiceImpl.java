package com.prajith.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prajith.dao.ProductDao;
import com.prajith.entity.ProductEntity;
import com.prajith.model.ProductDTO;
import com.prajith.vo.ProductDescriptionVO;
import com.prajith.vo.ProductWithDescriptionVO;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDao productDao;

	private ModelMapper mapper = new ModelMapper();

	@Autowired
	private ProductDescpClient productDescpClient;

	@Override
	public ProductDTO addProduct(ProductDTO product) {
		// TODO Auto-generated method stub
		ProductEntity entity = mapper.map(product, ProductEntity.class);
		ProductEntity respEntity = productDao.addProduct(entity);
		ProductDTO dto = mapper.map(respEntity, ProductDTO.class);
		return dto;
	}

	@Override
	public ProductDTO getProductById(Integer id) {
		Optional<ProductEntity> optional = productDao.getProductById(id);
		if (optional.isPresent()) {
			ProductEntity productEntity = optional.get();
			ProductDTO dto = mapper.map(productEntity, ProductDTO.class);
			return dto;
		} else {
			return null;
		}
	}

	@Override
	public List<ProductDTO> getProductByType(String type) {
		Optional<List<ProductEntity>> optional = productDao.getProductByType(type);
		if (optional.isPresent()) {
			List<ProductEntity> productEntity = optional.get();
			List<ProductDTO> dto = mapper.map(productEntity, new TypeToken<List<ProductDTO>>() {
			}.getType());
			return dto;
		} else {
			return null;
		}
	}

	@Override
	public ProductWithDescriptionVO getProductANdDescpById(Integer id) {
		Optional<ProductEntity> optional = productDao.getProductById(id);
		if (optional.isPresent()) {
			ProductEntity productEntity = optional.get();

			ProductDescriptionVO productDescptVO = productDescpClient.getProductDescp(id);
			ProductWithDescriptionVO edVO = new ProductWithDescriptionVO();
			edVO.setProductEntity(productEntity);
			edVO.setProductDescriptionVO(productDescptVO);
			return edVO;
		}
		return null;
	}

}
