package com.prajith.vo;

import java.io.Serializable;

import com.prajith.entity.ProductEntity;

import lombok.Data;

@Data
public class ProductWithDescriptionVO implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	private ProductEntity productEntity;
	private ProductDescriptionVO productDescriptionVO;

}
