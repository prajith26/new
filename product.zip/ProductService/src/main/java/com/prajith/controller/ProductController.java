package com.prajith.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prajith.model.ProductDTO;
import com.prajith.service.ProductService;
import com.prajith.vo.ProductWithDescriptionVO;

@RestController
@CrossOrigin
@RequestMapping("product")
public class ProductController {

	@Autowired
	private ProductService productService;

	@GetMapping
	public String welcome() {
		return "Welcome to Product Management System";
	}

	@PostMapping("/addproduct")
	public ProductDTO addProduct(@RequestBody ProductDTO product) {
		return productService.addProduct(product);
	}

	@GetMapping("/{id}")
	public ProductDTO getProductById(@PathVariable Integer id) {
		return productService.getProductById(id);
	}

	@GetMapping("/getproductbytype/{type}")
	public List<ProductDTO> getProductByType(@PathVariable String type) {
		return productService.getProductByType(type);
	}
	
	@GetMapping("/getproductdescpbyid/{id}")
	public ProductWithDescriptionVO getproductdescpbyid(@PathVariable Integer id) {
		return productService.getProductANdDescpById(id);
	}
}
