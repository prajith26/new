package com.prajith.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prajith.entity.ProductEntity;

public interface ProductRepository extends JpaRepository<ProductEntity, Integer> {
	Optional<List<ProductEntity>> findByType(String type);
}
