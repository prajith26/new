package com.prajith.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;

import com.prajith.entity.ProductEntity;
import com.prajith.repository.ProductRepository;

@Repository
public class ProductDaoImpl implements ProductDao {

	@Autowired
	private ProductRepository productRepo;

	@Override
	public ProductEntity addProduct(ProductEntity product) {
		try {
			return productRepo.save(product);
		} catch (DataIntegrityViolationException e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return null;
	}

	@Override
	public Optional<ProductEntity> getProductById(Integer id) {
		// TODO Auto-generated method stub
		return productRepo.findById(id);
	}

	@Override
	public Optional<List<ProductEntity>> getProductByType(String type) {
		// TODO Auto-generated method stub
		return productRepo.findByType(type);
	}

	@Override
	public boolean isProductAvailable(Integer id) {
		// TODO Auto-generated method stub
		return productRepo.existsById(id);
	}

}
