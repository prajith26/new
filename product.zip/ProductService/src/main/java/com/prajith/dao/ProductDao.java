package com.prajith.dao;

import java.util.List;
import java.util.Optional;

import com.prajith.entity.ProductEntity;


public interface ProductDao {

	public ProductEntity addProduct(ProductEntity product);
	public Optional<ProductEntity> getProductById(Integer id);
	public Optional<List<ProductEntity>> getProductByType(String type);
	public boolean isProductAvailable(Integer id);
}
