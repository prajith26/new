package com.prajith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PpEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
