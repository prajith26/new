package com.prajith.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.prajith.entity.ProductDescpEntity;
import com.prajith.repository.ProductDescpRepository;

@Repository
public class ProductDescpDao {

	@Autowired
	private ProductDescpRepository repo;

	public ProductDescpEntity addProductDesp(ProductDescpEntity entity) {
		return repo.save(entity);
	}

	public Optional<ProductDescpEntity> getProductDespById(Integer id) {
		return repo.findById(id);
	}
}
