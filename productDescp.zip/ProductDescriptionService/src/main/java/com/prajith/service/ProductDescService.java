package com.prajith.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prajith.dao.ProductDescpDao;
import com.prajith.entity.ProductDescpEntity;
import com.prajith.model.ProductModel;

@Service
public class ProductDescService {

	@Autowired
	private ProductDescpDao despDao;

	private ModelMapper mapper = new ModelMapper();

	public ProductModel addProductDescp(ProductModel descp) {
		ProductDescpEntity entity = mapper.map(descp, ProductDescpEntity.class);
		ProductDescpEntity respEntity = despDao.addProductDesp(entity);
		return mapper.map(respEntity, ProductModel.class);
	}

	public ProductModel getProductDescpById(Integer id) {
		Optional<ProductDescpEntity> optional = despDao.getProductDespById(id);
		if (optional.isPresent()) {
			ProductDescpEntity productEntity = optional.get();
			ProductModel dto = mapper.map(productEntity, ProductModel.class);
			return dto;
		} else {
			return null;
		}
	}
}
