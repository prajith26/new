package com.prajith.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prajith.model.ProductModel;
import com.prajith.service.ProductDescService;

@RestController
@CrossOrigin
@RequestMapping("description")
public class ProductDescpController {

	@Autowired
	private ProductDescService service;

	@PostMapping
	public ProductModel addProductdesp(@RequestBody ProductModel product) {
		return service.addProductDescp(product);
	}

	@GetMapping("/byid/{id}")
	public ProductModel getProductDescpById(@PathVariable Integer id) {
		return service.getProductDescpById(id);
	}
}
