package com.prajith.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "product_description")
public class ProductDescpEntity {
	private String brand;
	private String model;
	private String prize;
	
	@Id
	private Integer id;
}
