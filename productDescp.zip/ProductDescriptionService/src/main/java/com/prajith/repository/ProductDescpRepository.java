package com.prajith.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prajith.entity.ProductDescpEntity;

public interface ProductDescpRepository extends JpaRepository<ProductDescpEntity, Integer> {

}
